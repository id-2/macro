import { CodeHighlightNode, CodeNode } from '@lexical/code';
import { AutoLinkNode, LinkNode } from '@lexical/link';
import { ListItemNode, ListNode } from '@lexical/list';
import { MarkNode } from '@lexical/mark';
import { HeadingNode, QuoteNode } from '@lexical/rich-text';
import { TableCellNode, TableNode, TableRowNode } from '@lexical/table';
import {
  type KlassConstructor,
  type LexicalNode,
  type LexicalNodeReplacement,
  LineBreakNode,
  ParagraphNode,
  TabNode,
  TextNode,
} from 'lexical';
import { AccountManagerRequestNode } from './nodes/AccountManagerRequestNode';
import { AgentActivityNode } from './nodes/AgentActivityNode';
import { AgentContextNode } from './nodes/AgentContextNode';
import { AgentSessionMentionNode } from './nodes/AgentSessionMentionNode';
import { AwaitNode } from './nodes/AwaitNode';
import { BookingLinkMentionNode } from './nodes/BookingLinkMentionNode';
import { ClassedBlockNode } from './nodes/ClassedBlockNode';
import { CommentNode } from './nodes/CommentNode';
import { CompletionNode } from './nodes/CompletionNode';
import { ConnectAppNode } from './nodes/ConnectAppNode';
import { ContactMentionNode } from './nodes/ContactMentionNode';
import { CursorSystemNotificationNode } from './nodes/CursorSystemNotificationNode';
import { CustomCodeNode } from './nodes/CustomCodeNode';
import { DatabaseQueryNode } from './nodes/DatabaseQueryNode';
import { DateMentionNode } from './nodes/DateMentionNode';
import { DetailsNode, DetailsSummaryNode } from './nodes/DetailsNode';
import { DiffDeleteNode } from './nodes/DiffDeleteNode';
import { DiffInsertNode } from './nodes/DiffInsertNode';
import { DiffNode } from './nodes/DiffNode';
import { DiffTextNode } from './nodes/DiffTextNode';
import { DocumentCardNode } from './nodes/DocumentCardNode';
import { DocumentMentionNode } from './nodes/DocumentMentionNode';
import { EquationNode } from './nodes/EquationNode';
import { GroupMentionNode } from './nodes/GroupMentionNode';
import { HorizontalRuleNode } from './nodes/HorizontalRuleNode';
import { HtmlRenderNode } from './nodes/HtmlRenderNode';
import { ImageNode } from './nodes/ImageNode';
import { InlineSearchNode } from './nodes/InlineSearchNode';
import { MagicChipNode } from './nodes/MagicChipNode';
import { PasteNode } from './nodes/PasteNode';
import { PullRequestMentionNode } from './nodes/PullRequestMentionNode';
import { ReplyTargetNode } from './nodes/ReplyTargetNode';
import { SearchMatchNode } from './nodes/SearchMatchNode';
import { SnapshotNode } from './nodes/SnapshotNode';
import { TagMentionNode } from './nodes/TagMentionNode';
import { TaskListNode } from './nodes/TaskListNode';
import { ThemeMentionNode } from './nodes/ThemeMentionNode';
import { UnknownMentionNode } from './nodes/UnknownMentionNode';
import { UnlinkedTextNode } from './nodes/UnlinkedTextNode';
import { UserMentionNode } from './nodes/UserMentionNode';
import { VideoNode } from './nodes/VideoNode';
import { WatermarkNode } from './nodes/WatermarkNode';

/**
 * The pre-specified types of base editor we have configured.
 */
export type EditorType =
  | 'plain-text'
  | 'markdown'
  | 'markdown-sync'
  | 'chat'
  | 'title'
  | 'calendar';

// Valid nodes must be enumerated at Editor construction. We can set up plugins
// lazily, but the node list must be specified fully upfront.
export type ValidNode =
  | KlassConstructor<typeof LexicalNode>
  | LexicalNodeReplacement;

export const SupportedNodeTypes = [
  ParagraphNode,
  TextNode,
  CodeNode,
  CustomCodeNode,
  DatabaseQueryNode,
  HeadingNode,
  LinkNode,
  AutoLinkNode,
  ListNode,
  TaskListNode,
  ListItemNode,
  QuoteNode,
  LineBreakNode,
  DocumentMentionNode,
  DocumentCardNode,
  PasteNode,
  UserMentionNode,
  ContactMentionNode,
  DateMentionNode,
  PullRequestMentionNode,
  BookingLinkMentionNode,
  AgentSessionMentionNode,
  ReplyTargetNode,
  GroupMentionNode,
  InlineSearchNode,
  UnlinkedTextNode,
  CodeHighlightNode,
  TabNode,
  ImageNode,
  VideoNode,
  TableNode,
  TableCellNode,
  TableRowNode,
  CompletionNode,
  MarkNode,
  CommentNode,
  SearchMatchNode,
  EquationNode,
  SnapshotNode,
  HorizontalRuleNode,
  DiffNode,
  DiffInsertNode,
  DiffDeleteNode,
  DiffTextNode,
  HtmlRenderNode,
  ClassedBlockNode,
  WatermarkNode,
  ThemeMentionNode,
  TagMentionNode,
  ConnectAppNode,
  AccountManagerRequestNode,
  UnknownMentionNode,
  AwaitNode,
  MagicChipNode,
  AgentActivityNode,
  AgentContextNode,
  CursorSystemNotificationNode,
] as const;

/**
 * Nodes for read-only rendering (messages, PR comments): every supported node
 * plus the ones only a renderer needs, such as GitHub's collapsible
 * `<details>` sections. Keep editor-only behavior out of these.
 */
export const StaticRenderNodeTypes = [
  ...SupportedNodeTypes,
  DetailsNode,
  DetailsSummaryNode,
] as const;

export const NodeReplacements: LexicalNodeReplacement[] = [
  {
    replace: CodeNode,
    with: (node: CodeNode) => new CustomCodeNode(node.getLanguage()),
    withKlass: CustomCodeNode,
  },
  {
    replace: ListNode,
    with: (node: ListNode) =>
      new TaskListNode(node.getListType(), node.getStart()),
    withKlass: TaskListNode,
  },
];

function exclude(exclusions: ValidNode[]) {
  return SupportedNodeTypes.filter((n) => !exclusions.includes(n));
}

/**
 * You cannot add nodes to the editor after it has been created. This is a
 * mapping of the editor type to the nodes that are available for that editor.
 * If you want an editor with a custom set of nodes, this is the place for that.
 */
export const RegisteredNodesByType: { [K in EditorType]: ValidNode[] } = {
  'plain-text': [ParagraphNode, TextNode],
  markdown: [...SupportedNodeTypes],
  'markdown-sync': [...SupportedNodeTypes],
  // Chat carries URL images (GIFs); uploaded media still goes as attachments,
  // and the Image/Video slash actions need VideoNode, so they stay hidden.
  chat: exclude([VideoNode]),
  // Calendar descriptions are provider-supplied HTML from anyone who can write
  // the event, so the editor must not carry a node that renders raw markup.
  calendar: exclude([HtmlRenderNode, ImageNode, VideoNode]),
  title: [ParagraphNode, TextNode, InlineSearchNode],
} as const;
