# Lexical core

## What it is

Shared Lexical nodes and Markdown conversion for web editors, message renderers,
and backend document transformations.

## Start here

- `transformers/index.ts`: internal, external, and combined import/export sets.
- `utils/auto-link.ts` and `transformers/auto-link.ts`: shared URL matching and
  its adapter to Lexical's inline importer.
- `README.md`: persisted link and explicit-unlink behavior.

## Boundaries

Keep runtime code independent of the web app and browser-only modules. The web
composer imports the URL matcher from this package; do not duplicate it.

## Checks

- From `apps/web`: `bun run test --project lexical-core`.
- Run `bunx @biomejs/biome ci <changed-files>` from this directory for its
  format/lint rules; include untracked files before the first commit.
- Link changes also run `bun run test --project core linksPlugin.test.ts
  StaticMarkdown.test.tsx` in `apps/web`, and the browser check documented in
  `apps/web/src/lib/core/component/LexicalMarkdown/component/core/browser-test/README.md`.

## Gotchas

GitHub comment and PR bodies go through `normalizeGithubMarkdown`
(`utils/github-markdown.ts`) before import: it rewrites GitHub's raw HTML into
Markdown and keeps `<details>` for `transformers/details.ts`. `DetailsNode` is
registered only in `StaticRenderNodeTypes` (read-only renderers); the details
transformer is in every set but does nothing in an editor without the node, so
editors and services keep `<details>` as text.

Human user mention Markdown requires only a nonempty string `userId`; the importer
derives a missing email from `macro|` IDs so web name lookup and clipboard round
trips can resolve the user. Other identities still need an email or display name.
Document mention Markdown requires only `documentId` (cards also need
`blockName`); `documentName` is a cached label the chip replaces with the live
name, and agents routinely omit it. A date mention body is the JSON object or,
as models sometimes write it, a bare ISO date or timestamp;
`parseDateMentionBody` in `nodes/DateMentionNode.ts` reads both.

Keep URLs protected from inline formatting during import; matching rendered
text is too late. Preserve code, mention payloads, existing links, and escaped
literal URLs; escapes of `*`, `_`, `` ` `` and `~` alone don't make a URL
literal, because Lexical's export adds them to unlinked URL text (see
`README.md`). Keep unlink state through both Markdown and Lexical JSON saves.
`NodeReplacements` must copy `ListNode` start when wrapping as `TaskListNode`;
dropping it resets every typed `6.` marker to `1.`

An image under a list item is a child of that `ListItemNode`. Lexical runs
element transformers only on top-level nodes, so `listItemImage` exports it as
an indented line, and the image importers attach an indented image line after a
list to its last item. Add it to any new transformer set that has image
transformers.
