import { describe, expect, it } from 'vitest';
import {
  markdownToEmbeddingText,
  markdownToPlainText,
  markdownToSearchText,
  parseContactMentions,
  parseDateMentions,
  parseDocumentMentions,
  parseGroupMentions,
  parseLinks,
  parsePullRequestMentions,
  parseTagMentions,
  parseUserMentions,
  parseUserMentionsForSearch,
} from '../utils/parsers';

describe('parseUserMentions', () => {
  it('extracts email local part from user mention', () => {
    const input =
      '<m-user-mention>{"email":"john@example.com"}</m-user-mention>';
    expect(parseUserMentions(input)).toBe('john');
  });

  it('prefers displayName over email', () => {
    const input =
      '<m-user-mention>{"displayName":"John","email":"john@example.com"}</m-user-mention>';
    expect(parseUserMentions(input)).toBe('John');
  });

  it('returns empty string for missing email', () => {
    const input = '<m-user-mention>{"name":"John"}</m-user-mention>';
    expect(parseUserMentions(input)).toBe('');
  });

  it('returns empty string for invalid JSON', () => {
    const input = '<m-user-mention>invalid</m-user-mention>';
    expect(parseUserMentions(input)).toBe('');
  });

  it('handles multiple mentions', () => {
    const input =
      'Hello <m-user-mention>{"email":"a@b.com"}</m-user-mention> and <m-user-mention>{"email":"c@d.com"}</m-user-mention>';
    expect(parseUserMentions(input)).toBe('Hello a and c');
  });

  it('passes through text without mentions', () => {
    const input = 'Hello world';
    expect(parseUserMentions(input)).toBe('Hello world');
  });
});

describe('parseContactMentions', () => {
  it('extracts name from contact mention', () => {
    const input = '<m-contact-mention>{"name":"Jane Doe"}</m-contact-mention>';
    expect(parseContactMentions(input)).toBe('Jane Doe');
  });

  it('falls back to emailOrDomain when name is missing', () => {
    const input =
      '<m-contact-mention>{"emailOrDomain":"jane@example.com"}</m-contact-mention>';
    expect(parseContactMentions(input)).toBe('jane@example.com');
  });

  it('prefers name over emailOrDomain', () => {
    const input =
      '<m-contact-mention>{"name":"Jane","emailOrDomain":"jane@example.com"}</m-contact-mention>';
    expect(parseContactMentions(input)).toBe('Jane');
  });

  it('returns empty string for invalid JSON', () => {
    const input = '<m-contact-mention>not-json</m-contact-mention>';
    expect(parseContactMentions(input)).toBe('');
  });
});

describe('parseDateMentions', () => {
  it('extracts displayFormat from date mention', () => {
    const input =
      '<m-date-mention>{"displayFormat":"Tomorrow"}</m-date-mention>';
    expect(parseDateMentions(input)).toBe('Tomorrow');
  });

  it('returns empty string for missing displayFormat', () => {
    const input = '<m-date-mention>{"date":"2024-01-01"}</m-date-mention>';
    expect(parseDateMentions(input)).toBe('');
  });

  it('returns empty string for invalid JSON', () => {
    const input = '<m-date-mention>{broken</m-date-mention>';
    expect(parseDateMentions(input)).toBe('');
  });
});

describe('parseDocumentMentions', () => {
  it('extracts documentName from document mention', () => {
    const input =
      '<m-document-mention>{"documentName":"My Doc"}</m-document-mention>';
    expect(parseDocumentMentions(input)).toBe('My Doc');
  });

  it('returns empty string for missing documentName', () => {
    const input = '<m-document-mention>{"id":"123"}</m-document-mention>';
    expect(parseDocumentMentions(input)).toBe('');
  });

  it('returns empty string for invalid JSON', () => {
    const input = '<m-document-mention>???</m-document-mention>';
    expect(parseDocumentMentions(input)).toBe('');
  });

  it('decodes a name whose tag delimiters were written as JSON escapes', () => {
    const input =
      '<m-document-mention>{"documentName":"\\u003c/m-document-mention\\u003e \\u0026 Co"}</m-document-mention>';
    expect(parseDocumentMentions(input)).toBe('</m-document-mention> & Co');
  });
});

describe('parsePullRequestMentions', () => {
  it('extracts the label from a PR mention', () => {
    const input =
      '<m-pr-mention>{"id":"foreign-1","label":"macro/macro#123 Fix bug"}</m-pr-mention>';
    expect(parsePullRequestMentions(input)).toBe('macro/macro#123 Fix bug');
  });

  it('falls back to the id when label is missing', () => {
    const input = '<m-pr-mention>{"id":"foreign-1"}</m-pr-mention>';
    expect(parsePullRequestMentions(input)).toBe('foreign-1');
  });

  it('falls back to the GitHub reference for a URL-only mention', () => {
    const input =
      '<m-pr-mention>{"url":"https://github.com/macro-inc/macro/pull/7945","label":""}</m-pr-mention>';
    expect(parsePullRequestMentions(input)).toBe('macro-inc/macro#7945');
  });

  it('returns empty string for invalid JSON', () => {
    const input = '<m-pr-mention>???</m-pr-mention>';
    expect(parsePullRequestMentions(input)).toBe('');
  });
});

describe('parseLinks', () => {
  it('extracts text from link', () => {
    const input =
      '<m-link>{"url":"https://example.com","text":"Example"}</m-link>';
    expect(parseLinks(input)).toBe('Example');
  });

  it('falls back to url when text is missing', () => {
    const input = '<m-link>{"url":"https://example.com"}</m-link>';
    expect(parseLinks(input)).toBe('https://example.com');
  });

  it('prefers text over url', () => {
    const input =
      '<m-link>{"url":"https://example.com","text":"Click here"}</m-link>';
    expect(parseLinks(input)).toBe('Click here');
  });

  it('returns empty string for invalid JSON', () => {
    const input = '<m-link>broken</m-link>';
    expect(parseLinks(input)).toBe('');
  });

  it('handles link with title', () => {
    const input =
      '<m-link>{"url":"https://example.com","text":"Example","title":"A title"}</m-link>';
    expect(parseLinks(input)).toBe('Example');
  });
});

describe('parseGroupMentions', () => {
  it('extracts @alias from group mention', () => {
    const input = '<m-group-mention>{"groupAlias":"here"}</m-group-mention>';
    expect(parseGroupMentions(input)).toBe('@here');
  });

  it('handles missing groupAlias', () => {
    const input = '<m-group-mention>{}</m-group-mention>';
    expect(parseGroupMentions(input)).toBe('@');
  });

  it('handles invalid JSON', () => {
    const input = '<m-group-mention>invalid</m-group-mention>';
    expect(parseGroupMentions(input)).toBe('');
  });

  it('handles multiple group mentions', () => {
    const input =
      '<m-group-mention>{"groupAlias":"here"}</m-group-mention> and <m-group-mention>{"groupAlias":"team"}</m-group-mention>';
    expect(parseGroupMentions(input)).toBe('@here and @team');
  });

  it('passes through text without mentions', () => {
    const input = 'Hello world';
    expect(parseGroupMentions(input)).toBe('Hello world');
  });
});

describe('parseTagMentions', () => {
  it('extracts #name from a tag mention', () => {
    const input =
      '<m-tag>{"optionId":"tag-1","propertyDefinitionId":"prop-1","scope":"team","name":"Launch","color":"#0091FF"}</m-tag>';
    expect(parseTagMentions(input)).toBe('#Launch');
  });

  it('returns empty string for invalid JSON', () => {
    expect(parseTagMentions('<m-tag>invalid</m-tag>')).toBe('');
  });
});

describe('markdownToPlainText', () => {
  it('converts mixed content to plain text', () => {
    const input =
      'Hello <m-user-mention>{"email":"john@example.com"}</m-user-mention>, ' +
      'please review <m-document-mention>{"documentName":"Report"}</m-document-mention> ' +
      'by <m-date-mention>{"displayFormat":"Friday"}</m-date-mention>.';
    expect(markdownToPlainText(input)).toBe(
      'Hello john, please review Report by Friday.'
    );
  });

  it('handles text with links', () => {
    const input =
      'Check out <m-link>{"url":"https://example.com","text":"this link"}</m-link> for more info.';
    expect(markdownToPlainText(input)).toBe(
      'Check out this link for more info.'
    );
  });

  it('handles text with group mentions', () => {
    const input =
      'Hey <m-group-mention>{"groupAlias":"here"}</m-group-mention>, check this out!';
    expect(markdownToPlainText(input)).toBe('Hey @here, check this out!');
  });

  it('handles text with PR mentions', () => {
    const input =
      'See <m-pr-mention>{"id":"foreign-1","label":"macro/macro#123"}</m-pr-mention>.';
    expect(markdownToPlainText(input)).toBe('See macro/macro#123.');
  });

  it('handles text with tag mentions', () => {
    const input =
      'Ship <m-tag>{"optionId":"tag-1","propertyDefinitionId":"prop-1","scope":"team","name":"Launch"}</m-tag>.';
    expect(markdownToPlainText(input)).toBe('Ship #Launch.');
  });

  it('returns original text when no mentions present', () => {
    const input = 'Just plain text here.';
    expect(markdownToPlainText(input)).toBe('Just plain text here.');
  });

  it('handles empty string', () => {
    expect(markdownToPlainText('')).toBe('');
  });
});

describe('markdownToEmbeddingText', () => {
  it('keeps document and channel ids from document mentions', () => {
    const input =
      'Crash reported in <m-document-mention>{"documentId":"0195ceb6-ec2e-7023-80e4-6e084fa6cccd","blockName":"channel","documentName":"bug-reports","blockParams":{"channel_message_id":"019eb797-0ac1-7062-88ff-5202d1c81724"},"collapsed":false}</m-document-mention>';
    expect(markdownToEmbeddingText(input)).toBe(
      'Crash reported in [bug-reports](channel:0195ceb6-ec2e-7023-80e4-6e084fa6cccd#019eb797-0ac1-7062-88ff-5202d1c81724)'
    );
  });

  it('omits the fragment when there is no channel message id', () => {
    const input =
      '<m-document-mention>{"documentId":"doc-1","blockName":"md","documentName":"Report","blockParams":{}}</m-document-mention>';
    expect(markdownToEmbeddingText(input)).toBe('[Report](md:doc-1)');
  });

  it('falls back to the document name without a document id', () => {
    const input =
      '<m-document-mention>{"documentName":"Report"}</m-document-mention>';
    expect(markdownToEmbeddingText(input)).toBe('Report');
  });

  it('keeps ids from document cards', () => {
    const input =
      '<m-document-card>{"documentId":"doc-2","blockName":"md","documentName":"Spec","blockParams":{}}</m-document-card>';
    expect(markdownToEmbeddingText(input)).toBe('[Spec](md:doc-2)');
  });

  it('keeps ids from PR mentions', () => {
    const input =
      'See <m-pr-mention>{"id":"foreign-1","label":"macro/macro#123"}</m-pr-mention>.';
    expect(markdownToEmbeddingText(input)).toBe(
      'See [macro/macro#123](pr:foreign-1).'
    );
  });

  it('keeps tag names', () => {
    const input =
      'Ship <m-tag>{"optionId":"tag-1","propertyDefinitionId":"prop-1","scope":"team","name":"Launch"}</m-tag>.';
    expect(markdownToEmbeddingText(input)).toBe('Ship #Launch.');
  });

  it('keeps link urls', () => {
    const input =
      'See <m-link>{"url":"https://example.com","text":"this link"}</m-link>.';
    expect(markdownToEmbeddingText(input)).toBe(
      'See [this link](https://example.com).'
    );
  });

  it('reduces other mentions like markdownToPlainText', () => {
    const input =
      'Hello <m-user-mention>{"email":"john@example.com"}</m-user-mention> and ' +
      '<m-group-mention>{"groupAlias":"here"}</m-group-mention>, due ' +
      '<m-date-mention>{"displayFormat":"Friday"}</m-date-mention>.';
    expect(markdownToEmbeddingText(input)).toBe(
      'Hello john and @here, due Friday.'
    );
  });

  it('reduces contact and theme mentions to their names', () => {
    const input =
      'Ping <m-contact-mention>{"contactId":"c1","name":"Ness Chu","emailOrDomain":"ness@rox.one","isCompany":false}</m-contact-mention> re ' +
      '<m-theme-mention>{"name":"onboarding","data":{}}</m-theme-mention>';
    expect(markdownToEmbeddingText(input)).toBe('Ping Ness Chu re onboarding');
  });

  it('keeps ids from snapshots', () => {
    const input =
      '<m-snapshot>{"documentId":"doc-3","documentName":"Spec","blockName":"md","content":"ignored","snapshotDate":"2025-01-01"}</m-snapshot>';
    expect(markdownToEmbeddingText(input)).toBe('[Spec](md:doc-3)');
  });

  it('decodes base64 snapshots', () => {
    const payload = btoa(
      '{"documentId":"doc-3","documentName":"Spec","blockName":"md"}'
    );
    expect(markdownToEmbeddingText(`<m-snapshot>${payload}</m-snapshot>`)).toBe(
      '[Spec](md:doc-3)'
    );
  });

  it('keeps stable ids for dss images and urls for videos', () => {
    const input =
      '<m-image>{"url":"https://signed.example.com/x?sig=abc","alt":"crash screenshot","srcType":"dss","id":"img-1"}</m-image> ' +
      '<m-video>{"url":"https://videos.example.com/v1","srcType":"embed"}</m-video>';
    expect(markdownToEmbeddingText(input)).toBe(
      '[crash screenshot](dss:img-1) [video](https://videos.example.com/v1)'
    );
  });

  it('keeps equation sources and await placeholder text', () => {
    const input =
      '<m-katex-equation>{"equation":"E = mc^2","inline":true}</m-katex-equation> ' +
      '<m-await>{"awaitId":"a1","text":"generating...","inline":true}</m-await>';
    expect(markdownToEmbeddingText(input)).toBe('E = mc^2 generating...');
  });

  it('flattens tables and resolves mentions inside cells', () => {
    const input =
      '<m-table>' +
      '<m-table-row><m-table-cell>Owner</m-table-cell><m-table-cell>Task</m-table-cell></m-table-row>' +
      '<m-table-row><m-table-cell><m-user-mention>{"email":"a@b.com"}</m-user-mention></m-table-cell><m-table-cell>fix\\nbug</m-table-cell></m-table-row>' +
      '</m-table>';
    expect(markdownToEmbeddingText(input)).toBe('Owner | Task\na | fix bug');
  });

  it('unwraps email thread embeds and resolves mentions inside them', () => {
    const input =
      '<m-email-thread-embed>{"tag":"div","classes":["rox_quote"]}From <m-contact-mention>{"name":"Ness Chu"}</m-contact-mention>:\\nplease fix</m-email-thread-embed>';
    expect(markdownToEmbeddingText(input)).toBe('From Ness Chu:\nplease fix');
  });

  it('drops watermarks and unrecognized m-* tags entirely', () => {
    const input =
      'before <m-watermark>{"content":"made with macro"}</m-watermark>' +
      '<m-future-thing>{"some":"payload"}</m-future-thing> after';
    expect(markdownToEmbeddingText(input)).toBe('before  after');
  });

  it('drops tags with unparseable payloads', () => {
    expect(
      markdownToEmbeddingText(
        'x <m-document-mention>not json</m-document-mention> y'
      )
    ).toBe('x  y');
  });

  it('returns original text when no mentions present', () => {
    expect(markdownToEmbeddingText('Just plain text.')).toBe(
      'Just plain text.'
    );
  });
});

// Mirrors the backend indexer (`PlainTextFormatter::format_user`), so a
// query built from mention chips matches what the index holds.
describe('parseUserMentionsForSearch', () => {
  it('flattens a user mention to the email, not the display name', () => {
    const input =
      '<m-user-mention>{"userId":"macro|gab@rox.one","email":"gab@rox.one","displayName":"Gabriel"}</m-user-mention>';
    expect(parseUserMentionsForSearch(input)).toBe('gab@rox.one');
  });

  it('takes the email from the user id when the email field is missing', () => {
    const input =
      '<m-user-mention>{"userId":"macro|gab@rox.one","displayName":"Gabriel"}</m-user-mention>';
    expect(parseUserMentionsForSearch(input)).toBe('gab@rox.one');
  });

  it('flattens a bot mention to its display name', () => {
    const input =
      '<m-user-mention>{"userId":"bot|00000000-0000-0000-0000-00000000c5c5","email":"Cursor","displayName":"Cursor"}</m-user-mention>';
    expect(parseUserMentionsForSearch(input)).toBe('Cursor');
  });

  it('names other principals Guest, even with an email', () => {
    expect(
      parseUserMentionsForSearch(
        '<m-user-mention>{"userId":"guest|abc","email":"guest@example.com"}</m-user-mention>'
      )
    ).toBe('Guest');
    expect(
      parseUserMentionsForSearch(
        '<m-user-mention>{"userId":"macro|","email":"gab@rox.one"}</m-user-mention>'
      )
    ).toBe('Guest');
  });

  it('returns empty string for invalid JSON', () => {
    expect(
      parseUserMentionsForSearch('<m-user-mention>not json</m-user-mention>')
    ).toBe('');
  });
});

describe('markdownToSearchText', () => {
  it('differs from markdownToPlainText only in user mentions', () => {
    const input =
      'ping <m-user-mention>{"userId":"macro|gab@rox.one","email":"gab@rox.one","displayName":"Gabriel"}</m-user-mention> re <m-document-mention>{"documentName":"Roadmap"}</m-document-mention>';
    expect(markdownToPlainText(input)).toBe('ping Gabriel re Roadmap');
    expect(markdownToSearchText(input)).toBe('ping gab@rox.one re Roadmap');
  });

  it('passes plain text through', () => {
    expect(markdownToSearchText('Just plain text.')).toBe('Just plain text.');
  });
});
