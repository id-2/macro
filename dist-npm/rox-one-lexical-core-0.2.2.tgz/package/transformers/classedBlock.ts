import {
  $convertFromMarkdownString,
  $convertToMarkdownString,
  type ElementTransformer,
  type MultilineElementTransformer,
  TRANSFORMERS,
} from '@lexical/markdown';
import { $createQuoteNode, QuoteNode } from '@lexical/rich-text';
import type { ElementNode, LexicalNode } from 'lexical';
import {
  $createClassedBlockNode,
  $isClassedBlockNode,
  ClassedBlockNode,
  isAllowedTagName,
} from '../nodes/ClassedBlockNode';
import { CUSTOM_TRANSFORMERS } from './customTransformers';
import { createDetailsTransformer } from './details';
import { I_HTML_RENDER } from './htmlRender';
import { I_EQUATION_NODE } from './katex';
import {
  I_CONTACT_MENTION,
  I_DOCUMENT_MENTION,
  I_USER_MENTION,
} from './mentions';
import { xmlMatcher } from './transformers';
import {
  replaceElementWithUnknownMention,
  UnknownMentionNode,
} from './unknownFallback';

const TAG_ROX_QUOTE = 'm-email-thread-embed';
const REG_EXP_XML_ROX_QUOTE = xmlMatcher(TAG_ROX_QUOTE, '');
const REG_EXP_HTML_BLOCKQUOTE_START = /^\s*<blockquote\b[^>]*>\s*(.*)$/i;
const REG_EXP_HTML_BLOCKQUOTE_END = /^(.*?)\s*<\/blockquote>\s*$/i;
const REG_EXP_HTML_BLOCKQUOTE_TAG = /<\/?blockquote\b[^>]*>/gi;

// Transformers used inside rox_quote blocks
const ROX_QUOTE_TRANSFORMERS = [
  I_HTML_RENDER,
  ...CUSTOM_TRANSFORMERS,
  I_EQUATION_NODE,
  I_USER_MENTION,
  I_DOCUMENT_MENTION,
  I_CONTACT_MENTION,
  ...TRANSFORMERS,
];

// GitHub quotes can hold `<details>`; the transformer does nothing where the
// details nodes aren't registered.
const QUOTED_DETAILS = createDetailsTransformer(htmlBlockquoteTransformers);

function htmlBlockquoteTransformers() {
  return [
    QUOTED_DETAILS,
    HTML_BLOCKQUOTE,
    I_HTML_RENDER,
    ...CUSTOM_TRANSFORMERS,
    I_EQUATION_NODE,
    I_USER_MENTION,
    I_DOCUMENT_MENTION,
    I_CONTACT_MENTION,
    ...TRANSFORMERS,
  ];
}

function htmlBlockquoteContent(
  startMatch: Array<string>,
  endMatch: Array<string> | null,
  linesInBetween: Array<string> | null
): string {
  return [startMatch[1] ?? '', ...(linesInBetween ?? []), endMatch?.[1] ?? '']
    .join('\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .trim();
}

function consumeHtmlBlockquoteLine(
  line: string,
  startingDepth: number
): {
  closed: boolean;
  depth: number;
  text: string;
} {
  let depth = startingDepth;
  let cursor = 0;
  let text = '';
  REG_EXP_HTML_BLOCKQUOTE_TAG.lastIndex = 0;

  for (const match of line.matchAll(REG_EXP_HTML_BLOCKQUOTE_TAG)) {
    const tag = match[0];
    const index = match.index ?? 0;
    const isClosingTag = tag.startsWith('</');

    if (isClosingTag) {
      depth -= 1;
      if (depth === 0) {
        text += line.slice(cursor, index);
        return { closed: true, depth, text };
      }
      text += line.slice(cursor, index + tag.length);
      cursor = index + tag.length;
      continue;
    }

    depth += 1;
    text += line.slice(cursor, index + tag.length);
    cursor = index + tag.length;
  }

  text += line.slice(cursor);
  return { closed: false, depth, text };
}

function createHtmlBlockquoteNode(content: string): LexicalNode | false {
  const quoteNode = $createQuoteNode();
  const normalized = content.replace(/<br\s*\/?>/gi, '\n').trim();
  if (!normalized) return false;

  $convertFromMarkdownString(
    normalized,
    htmlBlockquoteTransformers(),
    quoteNode
  );
  return quoteNode;
}

function importHtmlBlockquote(
  lines: Array<string>,
  rootNode: ElementNode,
  startLineIndex: number,
  startMatch: RegExpMatchArray
): [boolean, number] | null {
  let depth = 1;
  const contentLines: string[] = [];

  for (let index = startLineIndex; index < lines.length; index++) {
    const line =
      index === startLineIndex ? (startMatch[1] ?? '') : lines[index];
    const consumed = consumeHtmlBlockquoteLine(line, depth);
    depth = consumed.depth;
    contentLines.push(consumed.text);

    if (consumed.closed) {
      const quoteNode = createHtmlBlockquoteNode(contentLines.join('\n'));
      if (!quoteNode) return null;
      rootNode.append(quoteNode);
      return [true, index];
    }
  }

  return null;
}

export const HTML_BLOCKQUOTE: MultilineElementTransformer = {
  dependencies: [QuoteNode],
  type: 'multiline-element',
  regExpStart: REG_EXP_HTML_BLOCKQUOTE_START,
  regExpEnd: REG_EXP_HTML_BLOCKQUOTE_END,
  export: () => null,
  handleImportAfterStartMatch: ({
    lines,
    rootNode,
    startLineIndex,
    startMatch,
  }) => importHtmlBlockquote(lines, rootNode, startLineIndex, startMatch),
  replace: (
    rootNode,
    children,
    startMatch,
    endMatch,
    linesInBetween,
    _isImport
  ) => {
    const quoteNode = $createQuoteNode();

    if (children?.length) {
      quoteNode.append(...children);
    } else {
      const content = htmlBlockquoteContent(
        startMatch,
        endMatch,
        linesInBetween
      );
      if (!content) return false;
      $convertFromMarkdownString(
        content,
        htmlBlockquoteTransformers(),
        quoteNode
      );
    }

    rootNode.append(quoteNode);
  },
};

export const I_ROX_QUOTE: ElementTransformer = {
  dependencies: [ClassedBlockNode, UnknownMentionNode],
  type: 'element',
  regExp: REG_EXP_XML_ROX_QUOTE,

  export: (node: LexicalNode) => {
    if (!$isClassedBlockNode(node)) {
      return null;
    }

    if (!node.__classes.includes('rox_quote')) {
      return null;
    }

    const metadata = JSON.stringify({
      tag: node.__tag,
      classes: node.__classes,
    });

    let output = `<${TAG_ROX_QUOTE}>${metadata}`;

    // Serialize children by passing the node itself
    const childrenMarkdown = $convertToMarkdownString(
      ROX_QUOTE_TRANSFORMERS,
      node
    );

    // Escape newlines in the content
    output += childrenMarkdown.replace(/\n/g, '\\n');
    output += `</${TAG_ROX_QUOTE}>`;

    return output;
  },

  replace: (node, _children, match, _isImport) => {
    try {
      const xmlContent = match[0];

      // Extract the metadata and content
      const metadataMatch = xmlContent.match(
        new RegExp(`<${TAG_ROX_QUOTE}>({.*?})`)
      );

      if (!metadataMatch || !metadataMatch[1]) {
        throw new Error('Missing macro-quote metadata');
      }

      const metadata = JSON.parse(metadataMatch[1]);
      const { tag, classes } = metadata;
      if (
        typeof tag !== 'string' ||
        !isAllowedTagName(tag) ||
        !Array.isArray(classes)
      ) {
        throw new Error('Invalid macro-quote metadata');
      }

      // Extract content after metadata
      const contentStart = metadataMatch[0].length;
      const contentEnd = xmlContent.lastIndexOf(`</${TAG_ROX_QUOTE}>`);
      const content = xmlContent.substring(contentStart, contentEnd);

      // Create the ClassedBlockNode
      const classedBlockNode = $createClassedBlockNode({
        tag: tag as keyof HTMLElementTagNameMap,
        classes,
      });

      // Parse and append children
      $convertFromMarkdownString(
        content.replace(/\\n/g, '\n'),
        ROX_QUOTE_TRANSFORMERS,
        classedBlockNode
      );

      node.replace(classedBlockNode);
    } catch (error) {
      console.error('Error parsing macro-quote:', error);
      replaceElementWithUnknownMention(node, 'Unknown Email Thread');
    }
  },
};
