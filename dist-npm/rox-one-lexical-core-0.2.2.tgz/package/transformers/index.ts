import type { Transformer } from '@lexical/markdown';
import { I_AGENT_ACTIVITY } from './agentActivity';
import { I_AGENT_CONTEXT } from './agentContext';
import { AUTO_LINK, ESCAPED_AUTO_LINK } from './auto-link';
import { I_AWAIT_NODE } from './await';
import { HTML_BLOCKQUOTE, I_ROX_QUOTE } from './classedBlock';
import { I_CURSOR_SYSTEM_NOTIFICATION } from './cursorSystemNotification';
import { CUSTOM_TRANSFORMERS } from './customTransformers';
import { I_DATABASE_QUERY, I_DATABASE_QUERY_BLOCK } from './databaseQuery';
import { createDetailsTransformer } from './details';
import { I_HTML_RENDER } from './htmlRender';
import { I_IMAGE_CONSTRAINED, IMAGE, listItemImage } from './image';
import {
  E_BLOCK_EQUATION_NODE,
  E_INLINE_EQUATION_NODE,
  E_MULTILINE_BLOCK_EQUATION_NODE,
  I_EQUATION_NODE,
} from './katex';
import { I_MAGIC_CHIP } from './magicChip';
import {
  E_AGENT_SESSION_MENTION,
  E_BOOKING_LINK_MENTION,
  E_CONTACT_MENTION,
  E_DATE_MENTION,
  E_DOCUMENT_CARD,
  E_DOCUMENT_MENTION,
  E_GROUP_MENTION,
  E_PR_MENTION,
  E_TAG_MENTION,
  E_USER_MENTION,
  I_ACCOUNT_MANAGER_REQUEST,
  I_AGENT_SESSION_CARD,
  I_AGENT_SESSION_MENTION,
  I_BOOKING_LINK_MENTION,
  I_CONNECT_APP,
  I_CONTACT_MENTION,
  I_DATE_MENTION,
  I_DOCUMENT_CARD,
  I_DOCUMENT_MENTION,
  I_GROUP_MENTION,
  I_PR_MENTION,
  I_TAG_MENTION,
  I_THEME_MENTION,
  I_USER_MENTION,
} from './mentions';
import { E_PASTE_NODE, I_PASTE_NODE } from './paste';
import { E_REPLY_TARGET_NODE, I_REPLY_TARGET_NODE } from './reply-target';
import { E_SNAPSHOT_NODE, I_SNAPSHOT_NODE } from './snapshot';
import { E_TABLE_NODE, I_TABLE_NODE } from './tables';
import {
  BR_TAG_TO_LINE_BREAK,
  HR,
  HTML_ENTITY_TRANSFORMERS,
  isConversionOnlyTransformer,
  LINK_XML,
  MARK_XML,
  PRESERVE_LINES,
  protectEmptyParagraphLines,
  SEARCH_MATCH,
  UNLINKED_TEXT,
} from './transformers';
import { UNKNOWN_MENTION } from './unknownMention';
import { I_VIDEO, VIDEO_LINK } from './video';
import { E_WATERMARK, I_WATERMARK } from './watermark';

export { ORDERED_LIST_ENTER } from './customTransformers';
export { isConversionOnlyTransformer, protectEmptyParagraphLines };

/**
 * Internal transformers for converting markdown between Lexical state and markdown.
 * The internal format uses XML-based syntax to represent nodes that fall outside of
 * standard markdown syntax.
 */
export const INTERNAL_TRANSFORMERS: Transformer[] = [
  createDetailsTransformer(() => INTERNAL_TRANSFORMERS),
  I_DATABASE_QUERY_BLOCK,
  I_DATABASE_QUERY,
  I_SNAPSHOT_NODE, // Must be before mentions to avoid matching inner tags in snapshot content
  I_PASTE_NODE, // Must be before mentions to avoid matching inner tags in paste content
  I_HTML_RENDER,
  PRESERVE_LINES,
  VIDEO_LINK, // Must be before LINK_XML to catch video URLs
  LINK_XML, // Prefer internal xml link to handle []() in link text
  MARK_XML,
  SEARCH_MATCH,
  HR,
  I_VIDEO,
  I_IMAGE_CONSTRAINED,
  IMAGE, // Standard markdown images (fallback)
  listItemImage(I_IMAGE_CONSTRAINED, IMAGE),
  I_USER_MENTION,
  I_GROUP_MENTION,
  I_DOCUMENT_MENTION,
  I_DOCUMENT_CARD,
  I_PR_MENTION,
  I_BOOKING_LINK_MENTION,
  I_AGENT_SESSION_CARD,
  I_AGENT_SESSION_MENTION,
  I_CONTACT_MENTION,
  I_DATE_MENTION,
  I_AWAIT_NODE,
  I_MAGIC_CHIP,
  I_AGENT_ACTIVITY,
  I_REPLY_TARGET_NODE,
  I_AGENT_CONTEXT,
  I_TABLE_NODE,
  HTML_BLOCKQUOTE,
  I_ROX_QUOTE,
  I_EQUATION_NODE,
  I_THEME_MENTION,
  I_TAG_MENTION,
  I_CONNECT_APP,
  I_ACCOUNT_MANAGER_REQUEST,
  I_WATERMARK,
  ...CUSTOM_TRANSFORMERS,
  ESCAPED_AUTO_LINK,
  AUTO_LINK,
  I_CURSOR_SYSTEM_NOTIFICATION, // After the code fence so a tag quoted in one stays text
  UNKNOWN_MENTION, // Must be last to act as fallback for unrecognized XML tags
];

/**
 * External transformers for converting Lexical to and from to GitHub Flavored (ish) Markdown.
 */
export const EXTERNAL_TRANSFORMERS: Transformer[] = [
  createDetailsTransformer(() => EXTERNAL_TRANSFORMERS),
  UNLINKED_TEXT,
  I_DATABASE_QUERY_BLOCK,
  I_DATABASE_QUERY,
  HR,
  MARK_XML,
  VIDEO_LINK,
  I_VIDEO,
  IMAGE,
  listItemImage(IMAGE),
  BR_TAG_TO_LINE_BREAK,
  E_TABLE_NODE,
  HTML_BLOCKQUOTE,
  E_USER_MENTION,
  E_GROUP_MENTION,
  E_PASTE_NODE, // export raw pasted text to external markdown
  I_DOCUMENT_MENTION, // for chat attachments
  E_DOCUMENT_MENTION,
  I_DOCUMENT_CARD, // for internal representation
  E_DOCUMENT_CARD,
  I_PR_MENTION,
  I_BOOKING_LINK_MENTION,
  I_AGENT_SESSION_MENTION,
  E_PR_MENTION,
  E_BOOKING_LINK_MENTION,
  E_AGENT_SESSION_MENTION,
  E_CONTACT_MENTION,
  E_DATE_MENTION,
  E_REPLY_TARGET_NODE,
  E_TAG_MENTION,
  I_CONNECT_APP, // agent replies render in the magic chip through this list
  // order matters
  E_MULTILINE_BLOCK_EQUATION_NODE,
  E_BLOCK_EQUATION_NODE,
  E_INLINE_EQUATION_NODE,
  E_WATERMARK,
  E_SNAPSHOT_NODE,
  ...HTML_ENTITY_TRANSFORMERS,
  ...CUSTOM_TRANSFORMERS,
  ESCAPED_AUTO_LINK,
  AUTO_LINK,
  UNKNOWN_MENTION, // Must be last to act as fallback for unrecognized XML tags
];

/**
 * Complete set of transformers supporting both internal and external markdown operations.
 */
export const ALL_TRANSFORMERS: Transformer[] = [
  createDetailsTransformer(() => ALL_TRANSFORMERS),
  I_DATABASE_QUERY_BLOCK,
  I_DATABASE_QUERY,
  I_SNAPSHOT_NODE, // Must be before mentions to avoid matching inner tags in snapshot content
  I_PASTE_NODE, // Must be before mentions to avoid matching inner tags in paste content
  I_HTML_RENDER,
  E_PASTE_NODE,
  PRESERVE_LINES,
  VIDEO_LINK, // Must be before LINK_XML to catch video URLs
  LINK_XML, // Prefer internal xml link to handle []() in link text
  MARK_XML,
  SEARCH_MATCH,
  HR,
  I_VIDEO,
  I_IMAGE_CONSTRAINED,
  IMAGE,
  listItemImage(I_IMAGE_CONSTRAINED, IMAGE),
  BR_TAG_TO_LINE_BREAK,
  I_TABLE_NODE,
  E_TABLE_NODE,
  HTML_BLOCKQUOTE,
  E_SNAPSHOT_NODE,
  I_USER_MENTION,
  E_USER_MENTION,
  I_GROUP_MENTION,
  E_GROUP_MENTION,
  I_DOCUMENT_MENTION,
  E_DOCUMENT_MENTION,
  I_DOCUMENT_CARD,
  E_DOCUMENT_CARD,
  I_PR_MENTION,
  I_BOOKING_LINK_MENTION,
  I_AGENT_SESSION_CARD,
  I_AGENT_SESSION_MENTION,
  E_AGENT_SESSION_MENTION,
  E_PR_MENTION,
  E_BOOKING_LINK_MENTION,
  I_CONTACT_MENTION,
  E_CONTACT_MENTION,
  I_DATE_MENTION,
  E_DATE_MENTION,
  I_AWAIT_NODE,
  I_MAGIC_CHIP,
  I_AGENT_ACTIVITY,
  I_REPLY_TARGET_NODE,
  I_AGENT_CONTEXT,
  I_ROX_QUOTE,
  I_EQUATION_NODE,
  I_THEME_MENTION,
  I_TAG_MENTION,
  I_CONNECT_APP,
  I_ACCOUNT_MANAGER_REQUEST,
  I_WATERMARK,
  E_WATERMARK,
  E_TAG_MENTION,
  // order matters
  E_MULTILINE_BLOCK_EQUATION_NODE,
  E_BLOCK_EQUATION_NODE,
  E_INLINE_EQUATION_NODE,
  ...HTML_ENTITY_TRANSFORMERS,
  ...CUSTOM_TRANSFORMERS,
  ESCAPED_AUTO_LINK,
  AUTO_LINK,
  I_CURSOR_SYSTEM_NOTIFICATION, // After the code fence so a tag quoted in one stays text
  UNKNOWN_MENTION, // Must be last to act as fallback for unrecognized XML tags
];
