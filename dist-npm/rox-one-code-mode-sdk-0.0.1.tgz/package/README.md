# Code-mode dependencies and documentation

This build package bundles the actual public `@rox-one/sdk` and Handlebars for
Deno. It adds no tool-name proxy or alternate API. Nested namespaces, entity
handles, promises and async iterators retain the public SDK implementation.

The agent supplies a JavaScript ES module exporting `async main(context)`. The
trusted bootstrap provides authenticated `macro`, `session`, and `execution`
handles plus `token`, `hosts`, `sessionId` and `executionId`. Explicit imports from
`@rox-one/sdk` and `handlebars` resolve to local build artifacts; no downloads
or TypeScript compilation happen during a run. SDK local portmap discovery is
removed from the bundle because service hosts are supplied by the harness.

The harness mints a Rox API JWT for the owner, lasting 60 seconds, after the
session's execution approval policy permits the run. Its signed agent identity comes from
the authenticated session. SDK messages use that agent as sender and record the
owner as `triggered_by`; other SDK endpoints retain normal user authentication.
External chat reads, sends and media uploads use the credential owner's own
provider connection. Owner API tokens can send, including signed agent-attributed tokens;
bot credentials never send. Pairing and account/access controls require the person's
bearer session.
Deno permits network access only to configured Rox service hosts and denies
filesystem writes, arbitrary imports, subprocesses, environment access and FFI.
User API authorization and metering apply. Tokens expire; process exit does not
revoke them. Source and final results are journaled, credentials are not.
Individual HTTP calls are no longer represented as synthetic tool receipts.

`main` returns `{data}` with an optional `reviews` array. Reviews are persisted through
`execution.reviews.create`; the UI reads actual session-scoped records and stays
interactive after execution. A review is an optional human workflow, not a
security barrier against direct SDK writes.

The independent `@rox-one/sdk-docs` package uses TypeDoc and its Markdown plugin to generate the canonical public SDK Markdown
hierarchy and an HTML site from one reflection model. The backend catalog is built from those Markdown pages: an index per entity
(classes, methods with signatures, and types, by symbol) and a reference per
symbol, each class split into its own methods, with links rewritten to the
symbols they name. Wire types an entity reaches are included as symbols; a name
two pages share is qualified by its service or entity (`storage.Message`).
Discovery uses at most 32 topics; agent and host setup share a topic, as do
native channels, external chats and WhatsApp. New SDK
services must also be registered in the generated operation-label catalog.
There is no separate declaration parser. Private, protected and internal members
are excluded. `DescribeCodeTools` provides the compact catalog, entity indexes and workflow
guides; `ReadCodeDocs` provides symbol references. See [documentation hosting](../sdk-docs/README.md). Jev
selects likely entity indexes before a code-mode turn, bounded by
one second and a context byte cap; failure leaves the compact catalog available.
There is no runtime documentation helper. See the
[agent playbook](../../crates/agent_code_mode/SKILL.md).

```sh
bun run --cwd packages/code-mode-sdk generate   # writes the assets to dist/
bun run --cwd packages/code-mode-sdk type-check
bun run --cwd packages/code-mode-sdk test
```

The generated `sdk.mjs`, `handlebars.mjs`, `documentation.json`,
`operations.json` (each SDK operation's label, method, path and whether it
writes), `hosts.json` (every service the SDK can reach, with its host in each
environment) and `sdk-types.json` (the SDK's declarations routine code is
type-checked against, with their fingerprint) are build outputs, never
committed. `crates/code_mode_assets`
builds them when it compiles: local cargo runs `scripts/generate.ts` with bun,
and Nix builds and Rust CI use the `code-mode-assets` flake package through
`CODE_MODE_ASSETS_DIR`. See that crate's `AGENTS.md`.
Real Deno integration tests live in `crates/code_execution`; public SDK entity
behavior is tested under `packages/sdk/tests`.
